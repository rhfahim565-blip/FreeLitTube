Free Lit Tube - ছোট Android project

Android Studio-তে এই ফোল্ডারটি Open করে Build > Build APK(s) নির্বাচন করুন।
অ্যাপটি খুললে Free Lit Tube এবং YouTube খুলুন বাটন দেখাবে।
