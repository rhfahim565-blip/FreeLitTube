package com.freelittube;
import android.app.Activity; import android.os.Bundle; import android.content.Intent; import android.net.Uri; import android.widget.Button;
public class MainActivity extends Activity { @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main); Button btn=findViewById(R.id.openYoutube); btn.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/")))); } }
